const storageService = firebase.storage();
const storageRef = storageService.ref();

const gymNews = document.querySelector('#gym-news');
const gymForm = document.querySelector('#add-gym-news');

document.querySelector('.file-select').addEventListener('change', handleFileUploadChange);

document.querySelector('.file-submit').addEventListener('click', handleFileUploadSubmit);
//Hello
function renderGymNews(doc) {
    let p = document.createElement('p');
    let title = document.createElement('span');
    let image = document.createElement('span');
    let content = document.createElement('span');

    p.setAttribute('data-id', doc.id);
    title.textContent = doc.data().title;
    image.textContent = doc.data().image;
    content.textContent = doc.data().content;

    p.appendChild(title);
    p.appendChild(image);
    p.appendChild(content);

    gymNews.appendChild(p);
};

gymForm.addEventListener('submit', (e) => {
    e.preventDefault();
    db.collection('gym').doc('BfMrKFL270yFqljpiqaN').update({
        title:   gymForm.title.value,
        image:   gymForm.image.value,
        content: gymForm.content.value
    });
    gymForm.title.value = "";
    gymForm.image.value = "";
    gymForm.content.value = "";
});

//getting data
db.collection('gym').get().then((snapshot) => {
    snapshot.docs.forEach(doc =>{
        renderGymNews(doc);
    })
});